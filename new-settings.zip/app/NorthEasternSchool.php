<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NorthEasternSchool extends Model
{
    public $fillable = ['name','county'];

}
