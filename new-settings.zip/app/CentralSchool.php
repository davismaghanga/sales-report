<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CentralSchool extends Model
{
    public $fillable = ['name','county'];

}
