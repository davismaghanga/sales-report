<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CoastSchool extends Model
{
    public $fillable = ['name','county'];

}
