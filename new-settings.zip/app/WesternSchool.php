<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WesternSchool extends Model
{
    public $fillable = ['name','county'];

}
