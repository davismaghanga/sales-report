<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NyanzaSchool extends Model
{
    public $fillable = ['name','county'];

}
