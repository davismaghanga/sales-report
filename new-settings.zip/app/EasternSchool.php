<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EasternSchool extends Model
{
    public $fillable = ['name','county'];

}
